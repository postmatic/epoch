<?php

//silence is golden

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
